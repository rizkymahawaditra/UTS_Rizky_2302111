package com.example.uts_2302111;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

public class EditProfileActivity extends Activity {
    private EditText nameInput, usernameInput, bioInput, websiteInput;
    private RadioGroup genderGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        nameInput = findViewById(R.id.editName);
        usernameInput = findViewById(R.id.editUsername);
        bioInput = findViewById(R.id.editBio);
        websiteInput = findViewById(R.id.editWebsite);
        genderGroup = findViewById(R.id.genderGroup);

        android.content.SharedPreferences prefs = getSharedPreferences("profile_data", MODE_PRIVATE);
        nameInput.setText(prefs.getString("name", "Rizky Mahawaditra"));
        usernameInput.setText(prefs.getString("username", "ryzo.daily"));
        bioInput.setText(prefs.getString("bio", "Collecting moments, not things ✨\n📍 Indonesia"));
        websiteInput.setText(prefs.getString("website", "www.instagram.com"));

        String gender = prefs.getString("gender", "Prefer not to say");
        if (gender.equals("Laki-laki")) genderGroup.check(R.id.genderMale);
        else if (gender.equals("Perempuan")) genderGroup.check(R.id.genderFemale);
        else genderGroup.check(R.id.genderNone);

        findViewById(R.id.backButton).setOnClickListener(v -> finish());
        findViewById(R.id.saveButton).setOnClickListener(v -> saveProfile());
    }

    private void saveProfile() {
        String name = nameInput.getText().toString().trim();
        String username = usernameInput.getText().toString().trim().replace("@", "");
        String bio = bioInput.getText().toString().trim();
        String website = websiteInput.getText().toString().trim();

        if (name.isEmpty() || username.isEmpty()) {
            Toast.makeText(this, "Nama dan username wajib diisi.", Toast.LENGTH_SHORT).show();
            return;
        }

        String gender = "Prefer not to say";
        int checked = genderGroup.getCheckedRadioButtonId();
        if (checked == R.id.genderMale) gender = "Laki-laki";
        else if (checked == R.id.genderFemale) gender = "Perempuan";

        getSharedPreferences("profile_data", MODE_PRIVATE).edit()
                .putString("name", name)
                .putString("username", username)
                .putString("bio", bio)
                .putString("website", website)
                .putString("gender", gender)
                .apply();

        Toast.makeText(this, "Profil berhasil disimpan", Toast.LENGTH_SHORT).show();
        finish();
    }
}
