package com.example.uts_2302111;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private TextView nameText, usernameText, bioText, websiteText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("profile_data", MODE_PRIVATE);

        nameText = findViewById(R.id.profileName);
        usernameText = findViewById(R.id.profileUsername);
        bioText = findViewById(R.id.profileBio);
        websiteText = findViewById(R.id.profileWebsite);

        Button editButton = findViewById(R.id.editProfileButton);
        editButton.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, EditProfileActivity.class)));

        findViewById(R.id.shareProfileButton).setOnClickListener(v -> {
            String shareText = "Profil " + prefs.getString("username", "ryzo.daily")
                    + "\n" + prefs.getString("bio", "Collecting moments ✨");
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, shareText);
            startActivity(Intent.createChooser(send, "Bagikan profil"));
        });

        int[] demoButtons = {R.id.navHome, R.id.navSearch, R.id.navAdd, R.id.navReels, R.id.navProfile};
        String[] messages = {"Beranda demo", "Pencarian demo", "Tambah postingan demo", "Reels demo", "Kamu sedang melihat profil"};
        for (int i = 0; i < demoButtons.length; i++) {
            final String message = messages[i];
            findViewById(demoButtons[i]).setOnClickListener(v ->
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }
        refreshProfile();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (prefs != null) refreshProfile();
    }

    private void refreshProfile() {
        nameText.setText(prefs.getString("name", "Rizky Mahawaditra"));
        usernameText.setText("@" + prefs.getString("username", "ryzo.daily"));
        bioText.setText(prefs.getString("bio", "Collecting moments, not things ✨\n📍 Indonesia"));
        String website = prefs.getString("website", "www.instagram.com");
        websiteText.setText(website.isEmpty() ? "" : "🔗 " + website);
    }
}
